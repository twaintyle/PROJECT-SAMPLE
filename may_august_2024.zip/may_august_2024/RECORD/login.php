<?php
  ob_start();
  session_start();
  if(isset($_SESSION["INTERN_ID"])){
    header("location:index.php");
  }
  include("dbconnect.php");
  
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="css/font.scss">
    <style>
    body{
      background-image: url("web job.png");
      background-size: cover;
      
    }
    </style>
</head>
<body style="background-color: brown;">
<h2 style="text-align: center; color: green">Camara Interns</h2>

<div class="login-box" style="margin-left: auto; margin-top: 50px;">
<h2>Login</h2>
<form action="<?php echo $_SERVER["PHP_SELF"];?>" method = "post">
  

    <?php
      if(isset($_POST["submit"])){

        $_POST["email"] = addslashes($_POST["email"]);
        $_POST["pwd"] = addslashes($_POST["pwd"]);

        $sql = "SELECT * FROM interns WHERE intern_mail = '{$_POST["email"]}' AND intern_pass = '{$_POST["pwd"]}'";
        $res = $db->query($sql);
        
        if($res->num_rows>0)
        {
          $row = $res->fetch_assoc();
          $_SESSION["INTERN_ID"] = $row["intern_id"];
          $_SESSION["INTERN_NAME"] = $row["intern_name"];
          header("location:index.php");
        }
        else{
          echo "<p style='color: tomato'>Invalid user details!</p>";
        }
      }
    ?>


    <div class="user-box">
      <input type="text" name="email" required="">
      <label>Email</label>
    </div>
    <div class="user-box">
      <input type="password" name="pwd" required="">
      <label>Password</label>
    </div>
    <a>
    <button type="submit" name="submit" style="color: white; font-size: 100%; font-family: inherit; border: none; padding: 0!important; background: none!important; cursor: pointer;">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      Login
    </button>
    </a>
    <br><br>
    <i>
    <div style="color: whitesmoke;">
      New User? &ensp;<span onclick="location.replace('signup.php')" 
      style="color:yellowgreen; text-decoration:underline; cursor:pointer">Signup Here..</span>
    </div>
    </i>
  </form>
</div>

<style>
  #login{
    background: whitesmoke;
  }

  #login:after{
    color: #8ae600;
  }
</style>

<?php ob_end_flush();?>

</body>
</html>