<?php
    $db =new mysqli("localhost", "root", "", "bmjknash_camara");
    if(!$db){
        echo "<h1>Unable to connect database</h1>";
    }
?>
 