<?php
    session_start();
    unset($_SESSION["AID"]);
    unset($_SESSION["INTERN_ID"]);
    session_destroy();
    header("location:index.php");
?>