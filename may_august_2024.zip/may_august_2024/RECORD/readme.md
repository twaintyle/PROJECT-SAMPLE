To install the project:
   (1) Requirements;
        -xampp local server of any version

    (2) Steps to be followed:
        ---->start your xampp application after you have downloaded it, *copy* the RECORD folder to the local diskC/ xampp/htdocs, 
            start the mysql service where you will be prompted to your browser for the phpmyadmin page
       ---->on the phpmyadmin, navigate to the database tab where you will be needed to create a new database;;;;
            the database name you are creating should be (bmjknash_camara)
        ----> while in the same database you have created, navigate to the import tab to import the sql file in the RECORD folder inside the htdocs in the xampp folder on your local disk C named as (interns.sql)
        ----> after the successive importation, you should be able to see the new tables created in the new database(bmjknash_camara)
       
   (3) go back to the xampp application and start the apache service afterwhich a browser will be opened.
            ----->on the address search bar, type localhost/RECORD/index.php and a user page will be displayed
                   SAMPLE LOGIN DETAILS
                    user---->> has to register first!
                    admin---->>admin/admin

          @@@ for more whatsapp me +254113156265, email at anthonydauz20708@gmail.com
                    thank you!
        